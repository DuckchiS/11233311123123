package com.example.projectfinal.controller;

import com.example.projectfinal.dto.Product_Share;
import com.example.projectfinal.dto.Top_Sale_Shop;
import com.example.projectfinal.dto.Total_Sale_Rank;
import com.example.projectfinal.service.MainWebService;
import com.example.projectfinal.vo.OrderVO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/")
public class MainWebController {
    private MainWebService mainWebService;

    public MainWebController(MainWebService mainWebService){
        this.mainWebService = mainWebService;
    }

    @GetMapping("/test")
    public ResponseEntity<Object> test(){
        Map<String, Object> result = new HashMap<>();

        List<Total_Sale_Rank> totalList = mainWebService.totalSale();
        result.put("Total_Sale_Rank", totalList);

        List<Top_Sale_Shop> topShops = mainWebService.topSaleShops();
        result.put("Top_Sale_Shop_Sum", topShops);

        List<Product_Share> productShare = mainWebService.productShares();
        result.put("Product_Share", productShare);

        return ResponseEntity.ok().body(result);
    }
}
