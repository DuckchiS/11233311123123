package com.example.projectfinal.service;

import com.example.projectfinal.dto.Product_Share;
import com.example.projectfinal.dto.Top_Sale_Shop;
import com.example.projectfinal.dto.Total_Sale_Rank;
import com.example.projectfinal.model.entity.Orders;
import com.example.projectfinal.repository.OrderRepository;
import com.example.projectfinal.vo.OrderVO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MainWebService {
    private OrderRepository orderRepository;

    public MainWebService(OrderRepository orderRepository){
        this.orderRepository = orderRepository;
    }

    public List<Total_Sale_Rank> totalSale(){
        List<Orders> orders = orderRepository.findAll();

        List<Total_Sale_Rank> orderVOList = orders.stream()
                .map(orderEntity -> Total_Sale_Rank.builder()
                        .total_sale(orderEntity.getOrder_Quantity())
                        .item_name(orderEntity.getItem().getItem_Name())
                        .build()
                )
                .limit(5)
                .collect(Collectors.toList());
        return orderVOList;
    }

    public List<Top_Sale_Shop> topSaleShops(){
        List<Orders> orders = orderRepository.findAll();

        List<Top_Sale_Shop> orderVOList = orders.stream().map(
                orderEntity -> Top_Sale_Shop.builder()
                        .sale_sum(orderEntity.getOrder_Price())
                        .shop_name(orderEntity.getItem().getItem_Name())
                        .build()
                )
                .limit(3)
                .collect(Collectors.toList());
        return orderVOList;
    }

    public List<Product_Share> productShares(){
        List<Orders> orders = orderRepository.findAll();

        List<Product_Share> orderVOList = orders.stream().map(
                orderEntity -> Product_Share.builder()
                        .category_name(orderEntity.getItem().getCategory().getCategory_Name())
                        .sale_rate(orderEntity.getOrder_Price())
                        .build()
                )
                .limit(3)
                .collect(Collectors.toList());
        return orderVOList;
    }


}
