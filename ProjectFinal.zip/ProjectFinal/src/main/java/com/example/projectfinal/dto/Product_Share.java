package com.example.projectfinal.dto;

import lombok.Builder;

@Builder
public class Product_Share {
    private String category_name;
    private int sale_rate;
}
