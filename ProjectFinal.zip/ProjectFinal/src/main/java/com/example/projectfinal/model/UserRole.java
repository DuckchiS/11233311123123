package com.example.projectfinal.model;

public enum UserRole {
    USER,
    ADMIN
}
