package com.example.projectfinal.dto;

import lombok.Builder;

@Builder
public class Total_Sale_Rank {
    private String item_name;
    private int total_sale;
}
